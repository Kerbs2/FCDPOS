﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Future_Craft_Digital.Purchasing_and_Stocks
{
    public partial class Order_and_Receive : Form
    {
        public Order_and_Receive()
        {
            InitializeComponent();
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void Order_and_Receive_Load(object sender, EventArgs e)
        {

        }
    }
}
