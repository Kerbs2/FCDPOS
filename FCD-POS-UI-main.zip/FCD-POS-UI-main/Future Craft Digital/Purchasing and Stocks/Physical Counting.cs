﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Future_Craft_Digital.Purchasing_and_Stocks
{
    public partial class Physical_Counting : Form
    {
        public Physical_Counting()
        {
            InitializeComponent();
        }
    }
}
