﻿namespace Future_Craft_Digital
{
    partial class Home
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Home));
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel6 = new System.Windows.Forms.Panel();
            this.BtnSalesReceipt = new System.Windows.Forms.Button();
            this.BtnCashiering = new System.Windows.Forms.Button();
            this.BtnOrderingKiosk = new System.Windows.Forms.Button();
            this.panel5 = new System.Windows.Forms.Panel();
            this.BtnDefectiveStocks = new System.Windows.Forms.Button();
            this.BtnCriticalProducts = new System.Windows.Forms.Button();
            this.BtnPhysicalCount = new System.Windows.Forms.Button();
            this.BtnStockMonitor = new System.Windows.Forms.Button();
            this.BtnOrderAndReceive = new System.Windows.Forms.Button();
            this.panel4 = new System.Windows.Forms.Panel();
            this.BtnBusinessInfo = new System.Windows.Forms.Button();
            this.BtnUserLog = new System.Windows.Forms.Button();
            this.BtnUserRecords = new System.Windows.Forms.Button();
            this.BtnManageSuppliers = new System.Windows.Forms.Button();
            this.BtnProductListing = new System.Windows.Forms.Button();
            this.SalesAndOrderLinkLabel = new System.Windows.Forms.LinkLabel();
            this.linkLabel1 = new System.Windows.Forms.LinkLabel();
            this.linkLabel2 = new System.Windows.Forms.LinkLabel();
            this.BtnPrint = new System.Windows.Forms.Button();
            this.BtnSearch = new System.Windows.Forms.Button();
            this.BtnRefresh = new System.Windows.Forms.Button();
            this.BtnDelete = new System.Windows.Forms.Button();
            this.BtnEdit = new System.Windows.Forms.Button();
            this.BtnNew = new System.Windows.Forms.Button();
            this.PanelShortCut = new System.Windows.Forms.Panel();
            this.openShortCutsLink = new System.Windows.Forms.LinkLabel();
            this.shortcutList = new System.Windows.Forms.ListView();
            this.columIcons = new System.Windows.Forms.ColumnHeader();
            this.ColumnHeader1 = new System.Windows.Forms.ColumnHeader();
            this.panel7 = new System.Windows.Forms.Panel();
            this.PanelAdvisory = new System.Windows.Forms.Panel();
            this.panel8 = new System.Windows.Forms.Panel();
            this.Panel9 = new System.Windows.Forms.Panel();
            this.advisoryLabel = new System.Windows.Forms.Label();
            this.txttabstop = new System.Windows.Forms.TextBox();
            this.Panel10 = new System.Windows.Forms.Panel();
            this.pnAdvisory_Cashier = new System.Windows.Forms.Panel();
            this.Label8 = new System.Windows.Forms.Label();
            this.PictureBox11 = new System.Windows.Forms.PictureBox();
            this.pnadvisory_Admin = new System.Windows.Forms.Panel();
            this.PictureBox6 = new System.Windows.Forms.PictureBox();
            this.PictureBox5 = new System.Windows.Forms.PictureBox();
            this.PictureBox4 = new System.Windows.Forms.PictureBox();
            this.PictureBox3 = new System.Windows.Forms.PictureBox();
            this.lblpurchasemonth = new System.Windows.Forms.Label();
            this.lblPurchaseYr = new System.Windows.Forms.Label();
            this.lblreorder = new System.Windows.Forms.Label();
            this.lblremainorder = new System.Windows.Forms.Label();
            this.lblinventory = new System.Windows.Forms.Label();
            this.lbltotalprod = new System.Windows.Forms.Label();
            this.lblmonthsales = new System.Windows.Forms.Label();
            this.lblyrsales = new System.Windows.Forms.Label();
            this.pnAdvisory_SalesAgent = new System.Windows.Forms.Panel();
            this.PictureBox14 = new System.Windows.Forms.PictureBox();
            this.Label9 = new System.Windows.Forms.Label();
            this.lblsalesagent_Criticalproduct = new System.Windows.Forms.Label();
            this.lblsalesagent_purchaseyear = new System.Windows.Forms.Label();
            this.lblsalesagent_purchaseMonth = new System.Windows.Forms.Label();
            this.PictureBox13 = new System.Windows.Forms.PictureBox();
            this.lblsalesagent_totalInventory = new System.Windows.Forms.Label();
            this.lblsalesagent_totalorder = new System.Windows.Forms.Label();
            this.PictureBox12 = new System.Windows.Forms.PictureBox();
            this.pnAdvisory_Stock = new System.Windows.Forms.Panel();
            this.lblstock_Undeliver = new System.Windows.Forms.Label();
            this.Label7 = new System.Windows.Forms.Label();
            this.lblstock_critical = new System.Windows.Forms.Label();
            this.PictureBox8 = new System.Windows.Forms.PictureBox();
            this.lblstock_received_year = new System.Windows.Forms.Label();
            this.lblstock_received_month = new System.Windows.Forms.Label();
            this.lblstock_tot_product = new System.Windows.Forms.Label();
            this.PictureBox7 = new System.Windows.Forms.PictureBox();
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.BtnHome = new System.Windows.Forms.Button();
            this.BtnExit = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.systemFileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.inventoryFileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.categoryListToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.categoryItemListToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.manageSuppliesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.suppliersProductToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.pointToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cashieringToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.salesReceiptToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.manageUsersToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.usersLogToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aboutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.reportsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.supplierProfileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.supplierProductsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.productsReorderToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.purchaseOrderToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.purchaseProductToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.stockBalancesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pointOfPaymentToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.salesCollectionReportToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.salesCollectionReportVOIDToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.collectionSummaryReportToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.salesReceiptReportToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.fastAndSlowMovingToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.fastMovingToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.slowMovingToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.panel3 = new System.Windows.Forms.Panel();
            this.dateLbl = new System.Windows.Forms.Label();
            this.timeLbl = new System.Windows.Forms.Label();
            this.lbltime = new System.Windows.Forms.Label();
            this.BtnLogout = new System.Windows.Forms.Button();
            this.lbltoday = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.lblUser = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.Label5 = new System.Windows.Forms.Label();
            this.userPic = new System.Windows.Forms.PictureBox();
            this.Label4 = new System.Windows.Forms.Label();
            this.Label3 = new System.Windows.Forms.Label();
            this.contentPanel = new System.Windows.Forms.Panel();
            this.HomePageLogo = new System.Windows.Forms.PictureBox();
            this.panel2.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel4.SuspendLayout();
            this.PanelShortCut.SuspendLayout();
            this.panel7.SuspendLayout();
            this.PanelAdvisory.SuspendLayout();
            this.panel8.SuspendLayout();
            this.Panel9.SuspendLayout();
            this.Panel10.SuspendLayout();
            this.pnAdvisory_Cashier.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox11)).BeginInit();
            this.pnadvisory_Admin.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox3)).BeginInit();
            this.pnAdvisory_SalesAgent.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox12)).BeginInit();
            this.pnAdvisory_Stock.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox7)).BeginInit();
            this.flowLayoutPanel1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.userPic)).BeginInit();
            this.contentPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.HomePageLogo)).BeginInit();
            this.SuspendLayout();
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.panel6);
            this.panel2.Controls.Add(this.panel5);
            this.panel2.Controls.Add(this.panel4);
            this.panel2.Controls.Add(this.SalesAndOrderLinkLabel);
            this.panel2.Controls.Add(this.linkLabel1);
            this.panel2.Controls.Add(this.linkLabel2);
            this.panel2.Location = new System.Drawing.Point(1, 142);
            this.panel2.Margin = new System.Windows.Forms.Padding(4);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(249, 608);
            this.panel2.TabIndex = 4;
            // 
            // panel6
            // 
            this.panel6.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.panel6.Controls.Add(this.BtnSalesReceipt);
            this.panel6.Controls.Add(this.BtnCashiering);
            this.panel6.Controls.Add(this.BtnOrderingKiosk);
            this.panel6.Location = new System.Drawing.Point(8, 477);
            this.panel6.Margin = new System.Windows.Forms.Padding(4);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(240, 109);
            this.panel6.TabIndex = 4;
            // 
            // BtnSalesReceipt
            // 
            this.BtnSalesReceipt.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.BtnSalesReceipt.BackColor = System.Drawing.Color.White;
            this.BtnSalesReceipt.Image = ((System.Drawing.Image)(resources.GetObject("BtnSalesReceipt.Image")));
            this.BtnSalesReceipt.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BtnSalesReceipt.Location = new System.Drawing.Point(4, 75);
            this.BtnSalesReceipt.Margin = new System.Windows.Forms.Padding(4);
            this.BtnSalesReceipt.Name = "BtnSalesReceipt";
            this.BtnSalesReceipt.Padding = new System.Windows.Forms.Padding(5, 2, 0, 2);
            this.BtnSalesReceipt.Size = new System.Drawing.Size(232, 29);
            this.BtnSalesReceipt.TabIndex = 5;
            this.BtnSalesReceipt.Text = "Sales Receipt";
            this.BtnSalesReceipt.UseVisualStyleBackColor = false;
            // 
            // BtnCashiering
            // 
            this.BtnCashiering.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.BtnCashiering.BackColor = System.Drawing.Color.White;
            this.BtnCashiering.Image = ((System.Drawing.Image)(resources.GetObject("BtnCashiering.Image")));
            this.BtnCashiering.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BtnCashiering.Location = new System.Drawing.Point(4, 41);
            this.BtnCashiering.Margin = new System.Windows.Forms.Padding(4);
            this.BtnCashiering.Name = "BtnCashiering";
            this.BtnCashiering.Padding = new System.Windows.Forms.Padding(5, 2, 0, 2);
            this.BtnCashiering.Size = new System.Drawing.Size(232, 29);
            this.BtnCashiering.TabIndex = 3;
            this.BtnCashiering.Text = "Cashiering";
            this.BtnCashiering.UseVisualStyleBackColor = false;
            // 
            // BtnOrderingKiosk
            // 
            this.BtnOrderingKiosk.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.BtnOrderingKiosk.BackColor = System.Drawing.Color.White;
            this.BtnOrderingKiosk.Image = ((System.Drawing.Image)(resources.GetObject("BtnOrderingKiosk.Image")));
            this.BtnOrderingKiosk.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BtnOrderingKiosk.Location = new System.Drawing.Point(4, 8);
            this.BtnOrderingKiosk.Margin = new System.Windows.Forms.Padding(4);
            this.BtnOrderingKiosk.Name = "BtnOrderingKiosk";
            this.BtnOrderingKiosk.Padding = new System.Windows.Forms.Padding(5, 2, 0, 2);
            this.BtnOrderingKiosk.Size = new System.Drawing.Size(232, 29);
            this.BtnOrderingKiosk.TabIndex = 2;
            this.BtnOrderingKiosk.Text = "Ordering Kiosk";
            this.BtnOrderingKiosk.UseVisualStyleBackColor = false;
            // 
            // panel5
            // 
            this.panel5.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.panel5.Controls.Add(this.BtnDefectiveStocks);
            this.panel5.Controls.Add(this.BtnCriticalProducts);
            this.panel5.Controls.Add(this.BtnPhysicalCount);
            this.panel5.Controls.Add(this.BtnStockMonitor);
            this.panel5.Controls.Add(this.BtnOrderAndReceive);
            this.panel5.Location = new System.Drawing.Point(4, 249);
            this.panel5.Margin = new System.Windows.Forms.Padding(4);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(240, 173);
            this.panel5.TabIndex = 3;
            // 
            // BtnDefectiveStocks
            // 
            this.BtnDefectiveStocks.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.BtnDefectiveStocks.BackColor = System.Drawing.Color.White;
            this.BtnDefectiveStocks.Image = ((System.Drawing.Image)(resources.GetObject("BtnDefectiveStocks.Image")));
            this.BtnDefectiveStocks.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BtnDefectiveStocks.Location = new System.Drawing.Point(6, 141);
            this.BtnDefectiveStocks.Margin = new System.Windows.Forms.Padding(4);
            this.BtnDefectiveStocks.Name = "BtnDefectiveStocks";
            this.BtnDefectiveStocks.Padding = new System.Windows.Forms.Padding(5, 2, 0, 2);
            this.BtnDefectiveStocks.Size = new System.Drawing.Size(232, 29);
            this.BtnDefectiveStocks.TabIndex = 7;
            this.BtnDefectiveStocks.Text = "Defective Stocks";
            this.BtnDefectiveStocks.UseVisualStyleBackColor = false;
            // 
            // BtnCriticalProducts
            // 
            this.BtnCriticalProducts.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.BtnCriticalProducts.BackColor = System.Drawing.Color.White;
            this.BtnCriticalProducts.Image = ((System.Drawing.Image)(resources.GetObject("BtnCriticalProducts.Image")));
            this.BtnCriticalProducts.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BtnCriticalProducts.Location = new System.Drawing.Point(4, 108);
            this.BtnCriticalProducts.Margin = new System.Windows.Forms.Padding(4);
            this.BtnCriticalProducts.Name = "BtnCriticalProducts";
            this.BtnCriticalProducts.Padding = new System.Windows.Forms.Padding(5, 2, 0, 2);
            this.BtnCriticalProducts.Size = new System.Drawing.Size(232, 29);
            this.BtnCriticalProducts.TabIndex = 6;
            this.BtnCriticalProducts.Text = "Critical Product(s)";
            this.BtnCriticalProducts.UseVisualStyleBackColor = false;
            // 
            // BtnPhysicalCount
            // 
            this.BtnPhysicalCount.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.BtnPhysicalCount.BackColor = System.Drawing.Color.White;
            this.BtnPhysicalCount.Image = global::Future_Craft_Digital.Properties.Resources.pie_chart__1_;
            this.BtnPhysicalCount.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BtnPhysicalCount.Location = new System.Drawing.Point(4, 74);
            this.BtnPhysicalCount.Margin = new System.Windows.Forms.Padding(4);
            this.BtnPhysicalCount.Name = "BtnPhysicalCount";
            this.BtnPhysicalCount.Padding = new System.Windows.Forms.Padding(5, 2, 0, 2);
            this.BtnPhysicalCount.Size = new System.Drawing.Size(232, 29);
            this.BtnPhysicalCount.TabIndex = 5;
            this.BtnPhysicalCount.Text = "Physical Counting";
            this.BtnPhysicalCount.UseVisualStyleBackColor = false;
            // 
            // BtnStockMonitor
            // 
            this.BtnStockMonitor.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.BtnStockMonitor.BackColor = System.Drawing.Color.White;
            this.BtnStockMonitor.Image = ((System.Drawing.Image)(resources.GetObject("BtnStockMonitor.Image")));
            this.BtnStockMonitor.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BtnStockMonitor.Location = new System.Drawing.Point(4, 40);
            this.BtnStockMonitor.Margin = new System.Windows.Forms.Padding(4);
            this.BtnStockMonitor.Name = "BtnStockMonitor";
            this.BtnStockMonitor.Padding = new System.Windows.Forms.Padding(5, 2, 0, 2);
            this.BtnStockMonitor.Size = new System.Drawing.Size(232, 29);
            this.BtnStockMonitor.TabIndex = 3;
            this.BtnStockMonitor.Text = "Stock Monitoring";
            this.BtnStockMonitor.UseVisualStyleBackColor = false;
            // 
            // BtnOrderAndReceive
            // 
            this.BtnOrderAndReceive.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.BtnOrderAndReceive.BackColor = System.Drawing.Color.White;
            this.BtnOrderAndReceive.Image = ((System.Drawing.Image)(resources.GetObject("BtnOrderAndReceive.Image")));
            this.BtnOrderAndReceive.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BtnOrderAndReceive.Location = new System.Drawing.Point(4, 8);
            this.BtnOrderAndReceive.Margin = new System.Windows.Forms.Padding(4);
            this.BtnOrderAndReceive.Name = "BtnOrderAndReceive";
            this.BtnOrderAndReceive.Padding = new System.Windows.Forms.Padding(5, 2, 0, 2);
            this.BtnOrderAndReceive.Size = new System.Drawing.Size(232, 29);
            this.BtnOrderAndReceive.TabIndex = 2;
            this.BtnOrderAndReceive.Text = "Order and Receive";
            this.BtnOrderAndReceive.UseVisualStyleBackColor = false;
            // 
            // panel4
            // 
            this.panel4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.panel4.Controls.Add(this.BtnBusinessInfo);
            this.panel4.Controls.Add(this.BtnUserLog);
            this.panel4.Controls.Add(this.BtnUserRecords);
            this.panel4.Controls.Add(this.BtnManageSuppliers);
            this.panel4.Controls.Add(this.BtnProductListing);
            this.panel4.Location = new System.Drawing.Point(6, 32);
            this.panel4.Margin = new System.Windows.Forms.Padding(4);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(240, 175);
            this.panel4.TabIndex = 2;
            // 
            // BtnBusinessInfo
            // 
            this.BtnBusinessInfo.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.BtnBusinessInfo.BackColor = System.Drawing.Color.White;
            this.BtnBusinessInfo.Image = ((System.Drawing.Image)(resources.GetObject("BtnBusinessInfo.Image")));
            this.BtnBusinessInfo.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BtnBusinessInfo.Location = new System.Drawing.Point(6, 141);
            this.BtnBusinessInfo.Margin = new System.Windows.Forms.Padding(4);
            this.BtnBusinessInfo.Name = "BtnBusinessInfo";
            this.BtnBusinessInfo.Padding = new System.Windows.Forms.Padding(5, 2, 0, 2);
            this.BtnBusinessInfo.Size = new System.Drawing.Size(232, 29);
            this.BtnBusinessInfo.TabIndex = 7;
            this.BtnBusinessInfo.Text = "Business Information";
            this.BtnBusinessInfo.UseVisualStyleBackColor = false;
            // 
            // BtnUserLog
            // 
            this.BtnUserLog.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.BtnUserLog.BackColor = System.Drawing.Color.White;
            this.BtnUserLog.Image = ((System.Drawing.Image)(resources.GetObject("BtnUserLog.Image")));
            this.BtnUserLog.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BtnUserLog.Location = new System.Drawing.Point(4, 108);
            this.BtnUserLog.Margin = new System.Windows.Forms.Padding(4);
            this.BtnUserLog.Name = "BtnUserLog";
            this.BtnUserLog.Padding = new System.Windows.Forms.Padding(5, 2, 0, 2);
            this.BtnUserLog.Size = new System.Drawing.Size(232, 29);
            this.BtnUserLog.TabIndex = 6;
            this.BtnUserLog.Text = "Users Log";
            this.BtnUserLog.UseVisualStyleBackColor = false;
            // 
            // BtnUserRecords
            // 
            this.BtnUserRecords.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.BtnUserRecords.BackColor = System.Drawing.Color.White;
            this.BtnUserRecords.Image = ((System.Drawing.Image)(resources.GetObject("BtnUserRecords.Image")));
            this.BtnUserRecords.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BtnUserRecords.Location = new System.Drawing.Point(4, 74);
            this.BtnUserRecords.Margin = new System.Windows.Forms.Padding(4);
            this.BtnUserRecords.Name = "BtnUserRecords";
            this.BtnUserRecords.Padding = new System.Windows.Forms.Padding(5, 2, 0, 2);
            this.BtnUserRecords.Size = new System.Drawing.Size(232, 29);
            this.BtnUserRecords.TabIndex = 5;
            this.BtnUserRecords.Text = "User Records";
            this.BtnUserRecords.UseVisualStyleBackColor = false;
            // 
            // BtnManageSuppliers
            // 
            this.BtnManageSuppliers.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.BtnManageSuppliers.BackColor = System.Drawing.Color.White;
            this.BtnManageSuppliers.Image = ((System.Drawing.Image)(resources.GetObject("BtnManageSuppliers.Image")));
            this.BtnManageSuppliers.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BtnManageSuppliers.Location = new System.Drawing.Point(4, 38);
            this.BtnManageSuppliers.Margin = new System.Windows.Forms.Padding(4);
            this.BtnManageSuppliers.Name = "BtnManageSuppliers";
            this.BtnManageSuppliers.Padding = new System.Windows.Forms.Padding(5, 2, 0, 2);
            this.BtnManageSuppliers.Size = new System.Drawing.Size(232, 29);
            this.BtnManageSuppliers.TabIndex = 3;
            this.BtnManageSuppliers.Text = "Manage Suppliers";
            this.BtnManageSuppliers.UseVisualStyleBackColor = false;
            // 
            // BtnProductListing
            // 
            this.BtnProductListing.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.BtnProductListing.BackColor = System.Drawing.Color.White;
            this.BtnProductListing.Image = ((System.Drawing.Image)(resources.GetObject("BtnProductListing.Image")));
            this.BtnProductListing.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BtnProductListing.Location = new System.Drawing.Point(4, 4);
            this.BtnProductListing.Margin = new System.Windows.Forms.Padding(4);
            this.BtnProductListing.Name = "BtnProductListing";
            this.BtnProductListing.Padding = new System.Windows.Forms.Padding(5, 2, 0, 2);
            this.BtnProductListing.Size = new System.Drawing.Size(232, 29);
            this.BtnProductListing.TabIndex = 2;
            this.BtnProductListing.Text = "Product Listing";
            this.BtnProductListing.UseVisualStyleBackColor = false;
            // 
            // SalesAndOrderLinkLabel
            // 
            this.SalesAndOrderLinkLabel.AutoSize = true;
            this.SalesAndOrderLinkLabel.Font = new System.Drawing.Font("Tahoma", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.SalesAndOrderLinkLabel.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.SalesAndOrderLinkLabel.LinkColor = System.Drawing.SystemColors.Highlight;
            this.SalesAndOrderLinkLabel.Location = new System.Drawing.Point(67, 452);
            this.SalesAndOrderLinkLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.SalesAndOrderLinkLabel.Name = "SalesAndOrderLinkLabel";
            this.SalesAndOrderLinkLabel.Size = new System.Drawing.Size(117, 17);
            this.SalesAndOrderLinkLabel.TabIndex = 1;
            this.SalesAndOrderLinkLabel.TabStop = true;
            this.SalesAndOrderLinkLabel.Text = "Sales and Order";
            // 
            // linkLabel1
            // 
            this.linkLabel1.AutoSize = true;
            this.linkLabel1.DisabledLinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(133)))), ((int)(((byte)(133)))), ((int)(((byte)(133)))));
            this.linkLabel1.Font = new System.Drawing.Font("Tahoma", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.linkLabel1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.linkLabel1.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.linkLabel1.LinkColor = System.Drawing.SystemColors.Highlight;
            this.linkLabel1.Location = new System.Drawing.Point(76, 10);
            this.linkLabel1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.linkLabel1.Name = "linkLabel1";
            this.linkLabel1.Size = new System.Drawing.Size(95, 17);
            this.linkLabel1.TabIndex = 1;
            this.linkLabel1.TabStop = true;
            this.linkLabel1.Text = "Maintenance";
            // 
            // linkLabel2
            // 
            this.linkLabel2.AutoSize = true;
            this.linkLabel2.Font = new System.Drawing.Font("Tahoma", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.linkLabel2.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.linkLabel2.LinkColor = System.Drawing.SystemColors.Highlight;
            this.linkLabel2.Location = new System.Drawing.Point(42, 228);
            this.linkLabel2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.linkLabel2.Name = "linkLabel2";
            this.linkLabel2.Size = new System.Drawing.Size(164, 17);
            this.linkLabel2.TabIndex = 1;
            this.linkLabel2.TabStop = true;
            this.linkLabel2.Text = "Purchasing and Stocks";
            // 
            // BtnPrint
            // 
            this.BtnPrint.BackColor = System.Drawing.Color.White;
            this.BtnPrint.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.BtnPrint.Image = ((System.Drawing.Image)(resources.GetObject("BtnPrint.Image")));
            this.BtnPrint.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.BtnPrint.Location = new System.Drawing.Point(616, 4);
            this.BtnPrint.Margin = new System.Windows.Forms.Padding(4);
            this.BtnPrint.Name = "BtnPrint";
            this.BtnPrint.Size = new System.Drawing.Size(94, 79);
            this.BtnPrint.TabIndex = 58;
            this.BtnPrint.Text = "Print";
            this.BtnPrint.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.BtnPrint.UseVisualStyleBackColor = false;
            // 
            // BtnSearch
            // 
            this.BtnSearch.BackColor = System.Drawing.Color.White;
            this.BtnSearch.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.BtnSearch.Image = ((System.Drawing.Image)(resources.GetObject("BtnSearch.Image")));
            this.BtnSearch.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.BtnSearch.Location = new System.Drawing.Point(412, 4);
            this.BtnSearch.Margin = new System.Windows.Forms.Padding(4);
            this.BtnSearch.Name = "BtnSearch";
            this.BtnSearch.Size = new System.Drawing.Size(94, 79);
            this.BtnSearch.TabIndex = 57;
            this.BtnSearch.Text = "Search";
            this.BtnSearch.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.BtnSearch.UseVisualStyleBackColor = false;
            // 
            // BtnRefresh
            // 
            this.BtnRefresh.BackColor = System.Drawing.Color.White;
            this.BtnRefresh.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.BtnRefresh.Image = ((System.Drawing.Image)(resources.GetObject("BtnRefresh.Image")));
            this.BtnRefresh.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.BtnRefresh.Location = new System.Drawing.Point(514, 4);
            this.BtnRefresh.Margin = new System.Windows.Forms.Padding(4);
            this.BtnRefresh.Name = "BtnRefresh";
            this.BtnRefresh.Size = new System.Drawing.Size(94, 79);
            this.BtnRefresh.TabIndex = 55;
            this.BtnRefresh.Text = "Refresh";
            this.BtnRefresh.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.BtnRefresh.UseVisualStyleBackColor = false;
            // 
            // BtnDelete
            // 
            this.BtnDelete.BackColor = System.Drawing.Color.White;
            this.BtnDelete.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.BtnDelete.Image = ((System.Drawing.Image)(resources.GetObject("BtnDelete.Image")));
            this.BtnDelete.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.BtnDelete.Location = new System.Drawing.Point(310, 4);
            this.BtnDelete.Margin = new System.Windows.Forms.Padding(4);
            this.BtnDelete.Name = "BtnDelete";
            this.BtnDelete.Size = new System.Drawing.Size(94, 79);
            this.BtnDelete.TabIndex = 54;
            this.BtnDelete.Text = "Delete";
            this.BtnDelete.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.BtnDelete.UseVisualStyleBackColor = false;
            // 
            // BtnEdit
            // 
            this.BtnEdit.BackColor = System.Drawing.Color.White;
            this.BtnEdit.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.BtnEdit.Image = ((System.Drawing.Image)(resources.GetObject("BtnEdit.Image")));
            this.BtnEdit.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.BtnEdit.Location = new System.Drawing.Point(208, 4);
            this.BtnEdit.Margin = new System.Windows.Forms.Padding(4);
            this.BtnEdit.Name = "BtnEdit";
            this.BtnEdit.Size = new System.Drawing.Size(94, 79);
            this.BtnEdit.TabIndex = 53;
            this.BtnEdit.Text = "Edit";
            this.BtnEdit.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.BtnEdit.UseVisualStyleBackColor = false;
            // 
            // BtnNew
            // 
            this.BtnNew.AllowDrop = true;
            this.BtnNew.BackColor = System.Drawing.Color.White;
            this.BtnNew.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.BtnNew.Image = ((System.Drawing.Image)(resources.GetObject("BtnNew.Image")));
            this.BtnNew.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.BtnNew.Location = new System.Drawing.Point(106, 4);
            this.BtnNew.Margin = new System.Windows.Forms.Padding(4);
            this.BtnNew.Name = "BtnNew";
            this.BtnNew.Size = new System.Drawing.Size(94, 79);
            this.BtnNew.TabIndex = 52;
            this.BtnNew.Text = "New";
            this.BtnNew.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.BtnNew.UseVisualStyleBackColor = false;
            // 
            // PanelShortCut
            // 
            this.PanelShortCut.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.PanelShortCut.BackColor = System.Drawing.Color.WhiteSmoke;
            this.PanelShortCut.Controls.Add(this.openShortCutsLink);
            this.PanelShortCut.Controls.Add(this.shortcutList);
            this.PanelShortCut.Location = new System.Drawing.Point(1064, 92);
            this.PanelShortCut.Margin = new System.Windows.Forms.Padding(4);
            this.PanelShortCut.Name = "PanelShortCut";
            this.PanelShortCut.Size = new System.Drawing.Size(199, 658);
            this.PanelShortCut.TabIndex = 34;
            // 
            // openShortCutsLink
            // 
            this.openShortCutsLink.AutoSize = true;
            this.openShortCutsLink.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.openShortCutsLink.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.openShortCutsLink.LinkColor = System.Drawing.Color.Black;
            this.openShortCutsLink.Location = new System.Drawing.Point(34, 11);
            this.openShortCutsLink.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.openShortCutsLink.Name = "openShortCutsLink";
            this.openShortCutsLink.Size = new System.Drawing.Size(104, 14);
            this.openShortCutsLink.TabIndex = 30;
            this.openShortCutsLink.TabStop = true;
            this.openShortCutsLink.Text = "Open Shortcuts";
            // 
            // shortcutList
            // 
            this.shortcutList.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.shortcutList.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columIcons,
            this.ColumnHeader1});
            this.shortcutList.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.shortcutList.FullRowSelect = true;
            this.shortcutList.Location = new System.Drawing.Point(10, 37);
            this.shortcutList.Margin = new System.Windows.Forms.Padding(4);
            this.shortcutList.Name = "shortcutList";
            this.shortcutList.Scrollable = false;
            this.shortcutList.Size = new System.Drawing.Size(182, 611);
            this.shortcutList.TabIndex = 31;
            this.shortcutList.UseCompatibleStateImageBehavior = false;
            this.shortcutList.View = System.Windows.Forms.View.SmallIcon;
            // 
            // columIcons
            // 
            this.columIcons.Text = "";
            // 
            // panel7
            // 
            this.panel7.Controls.Add(this.PanelAdvisory);
            this.panel7.Location = new System.Drawing.Point(1, 832);
            this.panel7.Margin = new System.Windows.Forms.Padding(0);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(1096, 64);
            this.panel7.TabIndex = 35;
            // 
            // PanelAdvisory
            // 
            this.PanelAdvisory.BackColor = System.Drawing.Color.Gray;
            this.PanelAdvisory.Controls.Add(this.panel8);
            this.PanelAdvisory.Controls.Add(this.Panel10);
            this.PanelAdvisory.ImeMode = System.Windows.Forms.ImeMode.On;
            this.PanelAdvisory.Location = new System.Drawing.Point(7, 14);
            this.PanelAdvisory.Margin = new System.Windows.Forms.Padding(4);
            this.PanelAdvisory.Name = "PanelAdvisory";
            this.PanelAdvisory.Size = new System.Drawing.Size(1494, 38);
            this.PanelAdvisory.TabIndex = 47;
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.Color.DimGray;
            this.panel8.Controls.Add(this.Panel9);
            this.panel8.Location = new System.Drawing.Point(0, 0);
            this.panel8.Margin = new System.Windows.Forms.Padding(4);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(213, 38);
            this.panel8.TabIndex = 45;
            // 
            // Panel9
            // 
            this.Panel9.BackColor = System.Drawing.Color.Black;
            this.Panel9.Controls.Add(this.advisoryLabel);
            this.Panel9.Controls.Add(this.txttabstop);
            this.Panel9.Location = new System.Drawing.Point(0, 0);
            this.Panel9.Margin = new System.Windows.Forms.Padding(4);
            this.Panel9.Name = "Panel9";
            this.Panel9.Size = new System.Drawing.Size(206, 39);
            this.Panel9.TabIndex = 47;
            // 
            // advisoryLabel
            // 
            this.advisoryLabel.AutoSize = true;
            this.advisoryLabel.Font = new System.Drawing.Font("Arial Black", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.advisoryLabel.ForeColor = System.Drawing.Color.White;
            this.advisoryLabel.Location = new System.Drawing.Point(45, 4);
            this.advisoryLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.advisoryLabel.Name = "advisoryLabel";
            this.advisoryLabel.Size = new System.Drawing.Size(132, 30);
            this.advisoryLabel.TabIndex = 41;
            this.advisoryLabel.Text = "ADVISORY";
            // 
            // txttabstop
            // 
            this.txttabstop.BackColor = System.Drawing.Color.DimGray;
            this.txttabstop.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txttabstop.Location = new System.Drawing.Point(83, 9);
            this.txttabstop.Margin = new System.Windows.Forms.Padding(4);
            this.txttabstop.Name = "txttabstop";
            this.txttabstop.Size = new System.Drawing.Size(116, 16);
            this.txttabstop.TabIndex = 4;
            // 
            // Panel10
            // 
            this.Panel10.BackColor = System.Drawing.Color.Gray;
            this.Panel10.Controls.Add(this.pnAdvisory_Cashier);
            this.Panel10.Controls.Add(this.pnadvisory_Admin);
            this.Panel10.Controls.Add(this.pnAdvisory_SalesAgent);
            this.Panel10.Controls.Add(this.pnAdvisory_Stock);
            this.Panel10.Location = new System.Drawing.Point(211, 0);
            this.Panel10.Margin = new System.Windows.Forms.Padding(4);
            this.Panel10.Name = "Panel10";
            this.Panel10.Size = new System.Drawing.Size(1282, 38);
            this.Panel10.TabIndex = 48;
            // 
            // pnAdvisory_Cashier
            // 
            this.pnAdvisory_Cashier.Controls.Add(this.Label8);
            this.pnAdvisory_Cashier.Controls.Add(this.PictureBox11);
            this.pnAdvisory_Cashier.Location = new System.Drawing.Point(1, 6);
            this.pnAdvisory_Cashier.Margin = new System.Windows.Forms.Padding(4);
            this.pnAdvisory_Cashier.Name = "pnAdvisory_Cashier";
            this.pnAdvisory_Cashier.Size = new System.Drawing.Size(1852, 28);
            this.pnAdvisory_Cashier.TabIndex = 53;
            this.pnAdvisory_Cashier.Visible = false;
            // 
            // Label8
            // 
            this.Label8.AutoSize = true;
            this.Label8.Font = new System.Drawing.Font("Arial Black", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Label8.ForeColor = System.Drawing.Color.White;
            this.Label8.Location = new System.Drawing.Point(955, 2);
            this.Label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Label8.Name = "Label8";
            this.Label8.Size = new System.Drawing.Size(734, 22);
            this.Label8.TabIndex = 61;
            this.Label8.Text = "GAZUTO MERCHANDISING INCORPORATED DEALER OF ALL PARTS AND ACCESORIES";
            // 
            // PictureBox11
            // 
            this.PictureBox11.Image = ((System.Drawing.Image)(resources.GetObject("PictureBox11.Image")));
            this.PictureBox11.Location = new System.Drawing.Point(934, 0);
            this.PictureBox11.Margin = new System.Windows.Forms.Padding(4);
            this.PictureBox11.Name = "PictureBox11";
            this.PictureBox11.Size = new System.Drawing.Size(18, 24);
            this.PictureBox11.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PictureBox11.TabIndex = 59;
            this.PictureBox11.TabStop = false;
            // 
            // pnadvisory_Admin
            // 
            this.pnadvisory_Admin.Controls.Add(this.PictureBox6);
            this.pnadvisory_Admin.Controls.Add(this.PictureBox5);
            this.pnadvisory_Admin.Controls.Add(this.PictureBox4);
            this.pnadvisory_Admin.Controls.Add(this.PictureBox3);
            this.pnadvisory_Admin.Controls.Add(this.lblpurchasemonth);
            this.pnadvisory_Admin.Controls.Add(this.lblPurchaseYr);
            this.pnadvisory_Admin.Controls.Add(this.lblreorder);
            this.pnadvisory_Admin.Controls.Add(this.lblremainorder);
            this.pnadvisory_Admin.Controls.Add(this.lblinventory);
            this.pnadvisory_Admin.Controls.Add(this.lbltotalprod);
            this.pnadvisory_Admin.Controls.Add(this.lblmonthsales);
            this.pnadvisory_Admin.Controls.Add(this.lblyrsales);
            this.pnadvisory_Admin.Location = new System.Drawing.Point(97, 6);
            this.pnadvisory_Admin.Margin = new System.Windows.Forms.Padding(4);
            this.pnadvisory_Admin.Name = "pnadvisory_Admin";
            this.pnadvisory_Admin.Size = new System.Drawing.Size(2296, 28);
            this.pnadvisory_Admin.TabIndex = 47;
            this.pnadvisory_Admin.Visible = false;
            // 
            // PictureBox6
            // 
            this.PictureBox6.Image = ((System.Drawing.Image)(resources.GetObject("PictureBox6.Image")));
            this.PictureBox6.Location = new System.Drawing.Point(1089, 2);
            this.PictureBox6.Margin = new System.Windows.Forms.Padding(4);
            this.PictureBox6.Name = "PictureBox6";
            this.PictureBox6.Size = new System.Drawing.Size(18, 24);
            this.PictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PictureBox6.TabIndex = 55;
            this.PictureBox6.TabStop = false;
            // 
            // PictureBox5
            // 
            this.PictureBox5.Image = ((System.Drawing.Image)(resources.GetObject("PictureBox5.Image")));
            this.PictureBox5.Location = new System.Drawing.Point(1568, 0);
            this.PictureBox5.Margin = new System.Windows.Forms.Padding(4);
            this.PictureBox5.Name = "PictureBox5";
            this.PictureBox5.Size = new System.Drawing.Size(18, 24);
            this.PictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PictureBox5.TabIndex = 54;
            this.PictureBox5.TabStop = false;
            // 
            // PictureBox4
            // 
            this.PictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("PictureBox4.Image")));
            this.PictureBox4.Location = new System.Drawing.Point(671, 0);
            this.PictureBox4.Margin = new System.Windows.Forms.Padding(4);
            this.PictureBox4.Name = "PictureBox4";
            this.PictureBox4.Size = new System.Drawing.Size(18, 24);
            this.PictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PictureBox4.TabIndex = 53;
            this.PictureBox4.TabStop = false;
            // 
            // PictureBox3
            // 
            this.PictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("PictureBox3.Image")));
            this.PictureBox3.Location = new System.Drawing.Point(18, 0);
            this.PictureBox3.Margin = new System.Windows.Forms.Padding(4);
            this.PictureBox3.Name = "PictureBox3";
            this.PictureBox3.Size = new System.Drawing.Size(18, 24);
            this.PictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PictureBox3.TabIndex = 48;
            this.PictureBox3.TabStop = false;
            // 
            // lblpurchasemonth
            // 
            this.lblpurchasemonth.AutoSize = true;
            this.lblpurchasemonth.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblpurchasemonth.ForeColor = System.Drawing.Color.Linen;
            this.lblpurchasemonth.Location = new System.Drawing.Point(1928, 4);
            this.lblpurchasemonth.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblpurchasemonth.Name = "lblpurchasemonth";
            this.lblpurchasemonth.Size = new System.Drawing.Size(295, 14);
            this.lblpurchasemonth.TabIndex = 36;
            this.lblpurchasemonth.Text = "Amount Purchase This Month =12,345,678.00";
            // 
            // lblPurchaseYr
            // 
            this.lblPurchaseYr.AutoSize = true;
            this.lblPurchaseYr.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblPurchaseYr.ForeColor = System.Drawing.Color.Linen;
            this.lblPurchaseYr.Location = new System.Drawing.Point(1586, 4);
            this.lblPurchaseYr.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblPurchaseYr.Name = "lblPurchaseYr";
            this.lblPurchaseYr.Size = new System.Drawing.Size(280, 14);
            this.lblPurchaseYr.TabIndex = 35;
            this.lblPurchaseYr.Text = "Amount Purchase This Year =12,345,678.00";
            // 
            // lblreorder
            // 
            this.lblreorder.AutoSize = true;
            this.lblreorder.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblreorder.ForeColor = System.Drawing.Color.Linen;
            this.lblreorder.Location = new System.Drawing.Point(1317, 4);
            this.lblreorder.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblreorder.Name = "lblreorder";
            this.lblreorder.Size = new System.Drawing.Size(208, 14);
            this.lblreorder.TabIndex = 34;
            this.lblreorder.Text = "Products on Critical level =1,234";
            // 
            // lblremainorder
            // 
            this.lblremainorder.AutoSize = true;
            this.lblremainorder.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblremainorder.ForeColor = System.Drawing.Color.Linen;
            this.lblremainorder.Location = new System.Drawing.Point(1109, 4);
            this.lblremainorder.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblremainorder.Name = "lblremainorder";
            this.lblremainorder.Size = new System.Drawing.Size(179, 14);
            this.lblremainorder.TabIndex = 33;
            this.lblremainorder.Text = "Remaining Order No =1,234";
            // 
            // lblinventory
            // 
            this.lblinventory.AutoSize = true;
            this.lblinventory.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblinventory.ForeColor = System.Drawing.Color.Linen;
            this.lblinventory.Location = new System.Drawing.Point(872, 4);
            this.lblinventory.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblinventory.Name = "lblinventory";
            this.lblinventory.Size = new System.Drawing.Size(177, 14);
            this.lblinventory.TabIndex = 29;
            this.lblinventory.Text = "Current Iventory =12,3456";
            // 
            // lbltotalprod
            // 
            this.lbltotalprod.AutoSize = true;
            this.lbltotalprod.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lbltotalprod.ForeColor = System.Drawing.Color.Linen;
            this.lbltotalprod.Location = new System.Drawing.Point(689, 4);
            this.lbltotalprod.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbltotalprod.Name = "lbltotalprod";
            this.lbltotalprod.Size = new System.Drawing.Size(151, 14);
            this.lbltotalprod.TabIndex = 27;
            this.lbltotalprod.Text = "Total Products = 1,234";
            // 
            // lblmonthsales
            // 
            this.lblmonthsales.AutoSize = true;
            this.lblmonthsales.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblmonthsales.ForeColor = System.Drawing.Color.Linen;
            this.lblmonthsales.Location = new System.Drawing.Point(346, 4);
            this.lblmonthsales.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblmonthsales.Name = "lblmonthsales";
            this.lblmonthsales.Size = new System.Drawing.Size(269, 14);
            this.lblmonthsales.TabIndex = 25;
            this.lblmonthsales.Text = "Total Sales In This Month =Php 1,234,567";
            // 
            // lblyrsales
            // 
            this.lblyrsales.AutoSize = true;
            this.lblyrsales.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblyrsales.ForeColor = System.Drawing.Color.Linen;
            this.lblyrsales.Location = new System.Drawing.Point(34, 4);
            this.lblyrsales.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblyrsales.Name = "lblyrsales";
            this.lblyrsales.Size = new System.Drawing.Size(262, 14);
            this.lblyrsales.TabIndex = 22;
            this.lblyrsales.Text = "Total Sales In This Year =Php 12,345,678";
            // 
            // pnAdvisory_SalesAgent
            // 
            this.pnAdvisory_SalesAgent.Controls.Add(this.PictureBox14);
            this.pnAdvisory_SalesAgent.Controls.Add(this.Label9);
            this.pnAdvisory_SalesAgent.Controls.Add(this.lblsalesagent_Criticalproduct);
            this.pnAdvisory_SalesAgent.Controls.Add(this.lblsalesagent_purchaseyear);
            this.pnAdvisory_SalesAgent.Controls.Add(this.lblsalesagent_purchaseMonth);
            this.pnAdvisory_SalesAgent.Controls.Add(this.PictureBox13);
            this.pnAdvisory_SalesAgent.Controls.Add(this.lblsalesagent_totalInventory);
            this.pnAdvisory_SalesAgent.Controls.Add(this.lblsalesagent_totalorder);
            this.pnAdvisory_SalesAgent.Controls.Add(this.PictureBox12);
            this.pnAdvisory_SalesAgent.Location = new System.Drawing.Point(38, 6);
            this.pnAdvisory_SalesAgent.Margin = new System.Windows.Forms.Padding(4);
            this.pnAdvisory_SalesAgent.Name = "pnAdvisory_SalesAgent";
            this.pnAdvisory_SalesAgent.Size = new System.Drawing.Size(2400, 28);
            this.pnAdvisory_SalesAgent.TabIndex = 53;
            this.pnAdvisory_SalesAgent.Visible = false;
            // 
            // PictureBox14
            // 
            this.PictureBox14.Image = ((System.Drawing.Image)(resources.GetObject("PictureBox14.Image")));
            this.PictureBox14.Location = new System.Drawing.Point(1483, 0);
            this.PictureBox14.Margin = new System.Windows.Forms.Padding(4);
            this.PictureBox14.Name = "PictureBox14";
            this.PictureBox14.Size = new System.Drawing.Size(18, 24);
            this.PictureBox14.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PictureBox14.TabIndex = 65;
            this.PictureBox14.TabStop = false;
            // 
            // Label9
            // 
            this.Label9.AutoSize = true;
            this.Label9.Font = new System.Drawing.Font("Arial Black", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Label9.ForeColor = System.Drawing.Color.White;
            this.Label9.Location = new System.Drawing.Point(1502, 2);
            this.Label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Label9.Name = "Label9";
            this.Label9.Size = new System.Drawing.Size(734, 22);
            this.Label9.TabIndex = 64;
            this.Label9.Text = "GAZUTO MERCHANDISING INCORPORATED DEALER OF ALL PARTS AND ACCESORIES";
            // 
            // lblsalesagent_Criticalproduct
            // 
            this.lblsalesagent_Criticalproduct.AutoSize = true;
            this.lblsalesagent_Criticalproduct.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblsalesagent_Criticalproduct.ForeColor = System.Drawing.Color.Linen;
            this.lblsalesagent_Criticalproduct.Location = new System.Drawing.Point(1292, 4);
            this.lblsalesagent_Criticalproduct.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblsalesagent_Criticalproduct.Name = "lblsalesagent_Criticalproduct";
            this.lblsalesagent_Criticalproduct.Size = new System.Drawing.Size(155, 14);
            this.lblsalesagent_Criticalproduct.TabIndex = 63;
            this.lblsalesagent_Criticalproduct.Text = "Critical Product =12345";
            // 
            // lblsalesagent_purchaseyear
            // 
            this.lblsalesagent_purchaseyear.AutoSize = true;
            this.lblsalesagent_purchaseyear.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblsalesagent_purchaseyear.ForeColor = System.Drawing.Color.Linen;
            this.lblsalesagent_purchaseyear.Location = new System.Drawing.Point(921, 4);
            this.lblsalesagent_purchaseyear.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblsalesagent_purchaseyear.Name = "lblsalesagent_purchaseyear";
            this.lblsalesagent_purchaseyear.Size = new System.Drawing.Size(311, 14);
            this.lblsalesagent_purchaseyear.TabIndex = 62;
            this.lblsalesagent_purchaseyear.Text = "Amount purchase for the year =Php 1234567.00";
            // 
            // lblsalesagent_purchaseMonth
            // 
            this.lblsalesagent_purchaseMonth.AutoSize = true;
            this.lblsalesagent_purchaseMonth.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblsalesagent_purchaseMonth.ForeColor = System.Drawing.Color.Linen;
            this.lblsalesagent_purchaseMonth.Location = new System.Drawing.Point(543, 4);
            this.lblsalesagent_purchaseMonth.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblsalesagent_purchaseMonth.Name = "lblsalesagent_purchaseMonth";
            this.lblsalesagent_purchaseMonth.Size = new System.Drawing.Size(318, 14);
            this.lblsalesagent_purchaseMonth.TabIndex = 61;
            this.lblsalesagent_purchaseMonth.Text = "Amount purchase for the month =Php 123456.00";
            // 
            // PictureBox13
            // 
            this.PictureBox13.Image = ((System.Drawing.Image)(resources.GetObject("PictureBox13.Image")));
            this.PictureBox13.Location = new System.Drawing.Point(517, 2);
            this.PictureBox13.Margin = new System.Windows.Forms.Padding(4);
            this.PictureBox13.Name = "PictureBox13";
            this.PictureBox13.Size = new System.Drawing.Size(18, 24);
            this.PictureBox13.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PictureBox13.TabIndex = 60;
            this.PictureBox13.TabStop = false;
            // 
            // lblsalesagent_totalInventory
            // 
            this.lblsalesagent_totalInventory.AutoSize = true;
            this.lblsalesagent_totalInventory.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblsalesagent_totalInventory.ForeColor = System.Drawing.Color.Linen;
            this.lblsalesagent_totalInventory.Location = new System.Drawing.Point(326, 4);
            this.lblsalesagent_totalInventory.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblsalesagent_totalInventory.Name = "lblsalesagent_totalInventory";
            this.lblsalesagent_totalInventory.Size = new System.Drawing.Size(157, 14);
            this.lblsalesagent_totalInventory.TabIndex = 59;
            this.lblsalesagent_totalInventory.Text = "Total Inventory =12345";
            // 
            // lblsalesagent_totalorder
            // 
            this.lblsalesagent_totalorder.AutoSize = true;
            this.lblsalesagent_totalorder.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblsalesagent_totalorder.ForeColor = System.Drawing.Color.Linen;
            this.lblsalesagent_totalorder.Location = new System.Drawing.Point(29, 4);
            this.lblsalesagent_totalorder.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblsalesagent_totalorder.Name = "lblsalesagent_totalorder";
            this.lblsalesagent_totalorder.Size = new System.Drawing.Size(233, 14);
            this.lblsalesagent_totalorder.TabIndex = 58;
            this.lblsalesagent_totalorder.Text = "Total order for the month  =123456";
            // 
            // PictureBox12
            // 
            this.PictureBox12.Image = ((System.Drawing.Image)(resources.GetObject("PictureBox12.Image")));
            this.PictureBox12.Location = new System.Drawing.Point(4, 2);
            this.PictureBox12.Margin = new System.Windows.Forms.Padding(4);
            this.PictureBox12.Name = "PictureBox12";
            this.PictureBox12.Size = new System.Drawing.Size(18, 24);
            this.PictureBox12.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PictureBox12.TabIndex = 57;
            this.PictureBox12.TabStop = false;
            // 
            // pnAdvisory_Stock
            // 
            this.pnAdvisory_Stock.Controls.Add(this.lblstock_Undeliver);
            this.pnAdvisory_Stock.Controls.Add(this.Label7);
            this.pnAdvisory_Stock.Controls.Add(this.lblstock_critical);
            this.pnAdvisory_Stock.Controls.Add(this.PictureBox8);
            this.pnAdvisory_Stock.Controls.Add(this.lblstock_received_year);
            this.pnAdvisory_Stock.Controls.Add(this.lblstock_received_month);
            this.pnAdvisory_Stock.Controls.Add(this.lblstock_tot_product);
            this.pnAdvisory_Stock.Controls.Add(this.PictureBox7);
            this.pnAdvisory_Stock.Location = new System.Drawing.Point(8, 6);
            this.pnAdvisory_Stock.Margin = new System.Windows.Forms.Padding(4);
            this.pnAdvisory_Stock.Name = "pnAdvisory_Stock";
            this.pnAdvisory_Stock.Size = new System.Drawing.Size(2114, 28);
            this.pnAdvisory_Stock.TabIndex = 56;
            this.pnAdvisory_Stock.Visible = false;
            // 
            // lblstock_Undeliver
            // 
            this.lblstock_Undeliver.AutoSize = true;
            this.lblstock_Undeliver.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblstock_Undeliver.ForeColor = System.Drawing.Color.Linen;
            this.lblstock_Undeliver.Location = new System.Drawing.Point(819, 4);
            this.lblstock_Undeliver.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblstock_Undeliver.Name = "lblstock_Undeliver";
            this.lblstock_Undeliver.Size = new System.Drawing.Size(146, 14);
            this.lblstock_Undeliver.TabIndex = 60;
            this.lblstock_Undeliver.Text = "Undeliver order =1234";
            // 
            // Label7
            // 
            this.Label7.AutoSize = true;
            this.Label7.Font = new System.Drawing.Font("Arial Black", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Label7.ForeColor = System.Drawing.Color.White;
            this.Label7.Location = new System.Drawing.Point(1235, 0);
            this.Label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Label7.Name = "Label7";
            this.Label7.Size = new System.Drawing.Size(734, 22);
            this.Label7.TabIndex = 60;
            this.Label7.Text = "GAZUTO MERCHANDISING INCORPORATED DEALER OF ALL PARTS AND ACCESORIES";
            // 
            // lblstock_critical
            // 
            this.lblstock_critical.AutoSize = true;
            this.lblstock_critical.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblstock_critical.ForeColor = System.Drawing.Color.Linen;
            this.lblstock_critical.Location = new System.Drawing.Point(997, 4);
            this.lblstock_critical.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblstock_critical.Name = "lblstock_critical";
            this.lblstock_critical.Size = new System.Drawing.Size(183, 14);
            this.lblstock_critical.TabIndex = 59;
            this.lblstock_critical.Text = "Product(s) on Critical =1234";
            // 
            // PictureBox8
            // 
            this.PictureBox8.Image = ((System.Drawing.Image)(resources.GetObject("PictureBox8.Image")));
            this.PictureBox8.Location = new System.Drawing.Point(1217, 0);
            this.PictureBox8.Margin = new System.Windows.Forms.Padding(4);
            this.PictureBox8.Name = "PictureBox8";
            this.PictureBox8.Size = new System.Drawing.Size(18, 24);
            this.PictureBox8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PictureBox8.TabIndex = 56;
            this.PictureBox8.TabStop = false;
            // 
            // lblstock_received_year
            // 
            this.lblstock_received_year.AutoSize = true;
            this.lblstock_received_year.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblstock_received_year.ForeColor = System.Drawing.Color.Linen;
            this.lblstock_received_year.Location = new System.Drawing.Point(242, 4);
            this.lblstock_received_year.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblstock_received_year.Name = "lblstock_received_year";
            this.lblstock_received_year.Size = new System.Drawing.Size(237, 14);
            this.lblstock_received_year.TabIndex = 59;
            this.lblstock_received_year.Text = "Received order for the year =123456";
            // 
            // lblstock_received_month
            // 
            this.lblstock_received_month.AutoSize = true;
            this.lblstock_received_month.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblstock_received_month.ForeColor = System.Drawing.Color.Linen;
            this.lblstock_received_month.Location = new System.Drawing.Point(528, 4);
            this.lblstock_received_month.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblstock_received_month.Name = "lblstock_received_month";
            this.lblstock_received_month.Size = new System.Drawing.Size(244, 14);
            this.lblstock_received_month.TabIndex = 58;
            this.lblstock_received_month.Text = "Received order for the month =12345";
            // 
            // lblstock_tot_product
            // 
            this.lblstock_tot_product.AutoSize = true;
            this.lblstock_tot_product.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblstock_tot_product.ForeColor = System.Drawing.Color.Linen;
            this.lblstock_tot_product.Location = new System.Drawing.Point(29, 4);
            this.lblstock_tot_product.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblstock_tot_product.Name = "lblstock_tot_product";
            this.lblstock_tot_product.Size = new System.Drawing.Size(181, 14);
            this.lblstock_tot_product.TabIndex = 56;
            this.lblstock_tot_product.Text = "Current Inventory  =12346 ";
            // 
            // PictureBox7
            // 
            this.PictureBox7.Image = ((System.Drawing.Image)(resources.GetObject("PictureBox7.Image")));
            this.PictureBox7.Location = new System.Drawing.Point(4, 0);
            this.PictureBox7.Margin = new System.Windows.Forms.Padding(4);
            this.PictureBox7.Name = "PictureBox7";
            this.PictureBox7.Size = new System.Drawing.Size(18, 24);
            this.PictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PictureBox7.TabIndex = 55;
            this.PictureBox7.TabStop = false;
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.flowLayoutPanel1.Controls.Add(this.BtnHome);
            this.flowLayoutPanel1.Controls.Add(this.BtnNew);
            this.flowLayoutPanel1.Controls.Add(this.BtnEdit);
            this.flowLayoutPanel1.Controls.Add(this.BtnDelete);
            this.flowLayoutPanel1.Controls.Add(this.BtnSearch);
            this.flowLayoutPanel1.Controls.Add(this.BtnRefresh);
            this.flowLayoutPanel1.Controls.Add(this.BtnPrint);
            this.flowLayoutPanel1.Controls.Add(this.BtnExit);
            this.flowLayoutPanel1.Location = new System.Drawing.Point(250, 0);
            this.flowLayoutPanel1.Margin = new System.Windows.Forms.Padding(4);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(1012, 94);
            this.flowLayoutPanel1.TabIndex = 36;
            // 
            // BtnHome
            // 
            this.BtnHome.BackColor = System.Drawing.Color.White;
            this.BtnHome.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.BtnHome.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.BtnHome.Image = ((System.Drawing.Image)(resources.GetObject("BtnHome.Image")));
            this.BtnHome.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.BtnHome.Location = new System.Drawing.Point(4, 4);
            this.BtnHome.Margin = new System.Windows.Forms.Padding(4);
            this.BtnHome.Name = "BtnHome";
            this.BtnHome.Size = new System.Drawing.Size(94, 79);
            this.BtnHome.TabIndex = 59;
            this.BtnHome.Text = "Home";
            this.BtnHome.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.BtnHome.UseVisualStyleBackColor = false;
            this.BtnHome.Click += new System.EventHandler(this.BtnHome_Click);
            // 
            // BtnExit
            // 
            this.BtnExit.BackColor = System.Drawing.Color.White;
            this.BtnExit.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.BtnExit.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.BtnExit.Image = ((System.Drawing.Image)(resources.GetObject("BtnExit.Image")));
            this.BtnExit.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.BtnExit.Location = new System.Drawing.Point(718, 4);
            this.BtnExit.Margin = new System.Windows.Forms.Padding(4);
            this.BtnExit.Name = "BtnExit";
            this.BtnExit.Size = new System.Drawing.Size(94, 79);
            this.BtnExit.TabIndex = 60;
            this.BtnExit.Text = "Exit";
            this.BtnExit.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.BtnExit.UseVisualStyleBackColor = false;
            this.BtnExit.Click += new System.EventHandler(this.BtnExit_Click);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.menuStrip1);
            this.panel1.Controls.Add(this.panel3);
            this.panel1.Location = new System.Drawing.Point(1, -2);
            this.panel1.Margin = new System.Windows.Forms.Padding(4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(250, 146);
            this.panel1.TabIndex = 37;
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.SystemColors.Control;
            this.menuStrip1.GripMargin = new System.Windows.Forms.Padding(0);
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.systemFileToolStripMenuItem,
            this.reportsToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Padding = new System.Windows.Forms.Padding(7, 2, 0, 2);
            this.menuStrip1.Size = new System.Drawing.Size(250, 24);
            this.menuStrip1.TabIndex = 16;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // systemFileToolStripMenuItem
            // 
            this.systemFileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.inventoryFileToolStripMenuItem,
            this.pointToolStripMenuItem,
            this.manageUsersToolStripMenuItem,
            this.usersLogToolStripMenuItem,
            this.aboutToolStripMenuItem,
            this.exitToolStripMenuItem});
            this.systemFileToolStripMenuItem.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.systemFileToolStripMenuItem.Name = "systemFileToolStripMenuItem";
            this.systemFileToolStripMenuItem.Size = new System.Drawing.Size(80, 20);
            this.systemFileToolStripMenuItem.Text = "System File";
            // 
            // inventoryFileToolStripMenuItem
            // 
            this.inventoryFileToolStripMenuItem.BackColor = System.Drawing.SystemColors.Control;
            this.inventoryFileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.categoryListToolStripMenuItem,
            this.categoryItemListToolStripMenuItem,
            this.toolStripSeparator1,
            this.manageSuppliesToolStripMenuItem,
            this.suppliersProductToolStripMenuItem,
            this.toolStripSeparator2});
            this.inventoryFileToolStripMenuItem.Name = "inventoryFileToolStripMenuItem";
            this.inventoryFileToolStripMenuItem.Size = new System.Drawing.Size(171, 22);
            this.inventoryFileToolStripMenuItem.Text = "Inventory File";
            // 
            // categoryListToolStripMenuItem
            // 
            this.categoryListToolStripMenuItem.Name = "categoryListToolStripMenuItem";
            this.categoryListToolStripMenuItem.Size = new System.Drawing.Size(175, 22);
            this.categoryListToolStripMenuItem.Text = "Category List";
            // 
            // categoryItemListToolStripMenuItem
            // 
            this.categoryItemListToolStripMenuItem.Name = "categoryItemListToolStripMenuItem";
            this.categoryItemListToolStripMenuItem.Size = new System.Drawing.Size(175, 22);
            this.categoryItemListToolStripMenuItem.Text = "Category Item List";
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(172, 6);
            // 
            // manageSuppliesToolStripMenuItem
            // 
            this.manageSuppliesToolStripMenuItem.Name = "manageSuppliesToolStripMenuItem";
            this.manageSuppliesToolStripMenuItem.Size = new System.Drawing.Size(175, 22);
            this.manageSuppliesToolStripMenuItem.Text = "Manage Supplies";
            // 
            // suppliersProductToolStripMenuItem
            // 
            this.suppliersProductToolStripMenuItem.Name = "suppliersProductToolStripMenuItem";
            this.suppliersProductToolStripMenuItem.Size = new System.Drawing.Size(175, 22);
            this.suppliersProductToolStripMenuItem.Text = "Suppliers Product";
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(172, 6);
            // 
            // pointToolStripMenuItem
            // 
            this.pointToolStripMenuItem.BackColor = System.Drawing.SystemColors.Control;
            this.pointToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.cashieringToolStripMenuItem,
            this.salesReceiptToolStripMenuItem});
            this.pointToolStripMenuItem.Name = "pointToolStripMenuItem";
            this.pointToolStripMenuItem.Size = new System.Drawing.Size(171, 22);
            this.pointToolStripMenuItem.Text = "Point Of Payment";
            // 
            // cashieringToolStripMenuItem
            // 
            this.cashieringToolStripMenuItem.Name = "cashieringToolStripMenuItem";
            this.cashieringToolStripMenuItem.Size = new System.Drawing.Size(146, 22);
            this.cashieringToolStripMenuItem.Text = "Cashiering";
            // 
            // salesReceiptToolStripMenuItem
            // 
            this.salesReceiptToolStripMenuItem.Name = "salesReceiptToolStripMenuItem";
            this.salesReceiptToolStripMenuItem.Size = new System.Drawing.Size(146, 22);
            this.salesReceiptToolStripMenuItem.Text = "Sales Receipt";
            // 
            // manageUsersToolStripMenuItem
            // 
            this.manageUsersToolStripMenuItem.BackColor = System.Drawing.SystemColors.Control;
            this.manageUsersToolStripMenuItem.Name = "manageUsersToolStripMenuItem";
            this.manageUsersToolStripMenuItem.Size = new System.Drawing.Size(171, 22);
            this.manageUsersToolStripMenuItem.Text = "Manage Users";
            // 
            // usersLogToolStripMenuItem
            // 
            this.usersLogToolStripMenuItem.BackColor = System.Drawing.SystemColors.Control;
            this.usersLogToolStripMenuItem.Name = "usersLogToolStripMenuItem";
            this.usersLogToolStripMenuItem.Size = new System.Drawing.Size(171, 22);
            this.usersLogToolStripMenuItem.Text = "Users Log";
            // 
            // aboutToolStripMenuItem
            // 
            this.aboutToolStripMenuItem.BackColor = System.Drawing.SystemColors.Control;
            this.aboutToolStripMenuItem.Name = "aboutToolStripMenuItem";
            this.aboutToolStripMenuItem.Size = new System.Drawing.Size(171, 22);
            this.aboutToolStripMenuItem.Text = "About";
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.BackColor = System.Drawing.SystemColors.Control;
            this.exitToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("exitToolStripMenuItem.Image")));
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(171, 22);
            this.exitToolStripMenuItem.Text = "Exit";
            // 
            // reportsToolStripMenuItem
            // 
            this.reportsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.supplierProfileToolStripMenuItem,
            this.supplierProductsToolStripMenuItem,
            this.productsReorderToolStripMenuItem,
            this.purchaseOrderToolStripMenuItem,
            this.purchaseProductToolStripMenuItem,
            this.stockBalancesToolStripMenuItem,
            this.pointOfPaymentToolStripMenuItem});
            this.reportsToolStripMenuItem.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.reportsToolStripMenuItem.Name = "reportsToolStripMenuItem";
            this.reportsToolStripMenuItem.Size = new System.Drawing.Size(61, 20);
            this.reportsToolStripMenuItem.Text = "Reports";
            // 
            // supplierProfileToolStripMenuItem
            // 
            this.supplierProfileToolStripMenuItem.Name = "supplierProfileToolStripMenuItem";
            this.supplierProfileToolStripMenuItem.Size = new System.Drawing.Size(205, 22);
            this.supplierProfileToolStripMenuItem.Text = "Supplier Profile";
            // 
            // supplierProductsToolStripMenuItem
            // 
            this.supplierProductsToolStripMenuItem.Name = "supplierProductsToolStripMenuItem";
            this.supplierProductsToolStripMenuItem.Size = new System.Drawing.Size(205, 22);
            this.supplierProductsToolStripMenuItem.Text = "Supplier Products";
            // 
            // productsReorderToolStripMenuItem
            // 
            this.productsReorderToolStripMenuItem.Name = "productsReorderToolStripMenuItem";
            this.productsReorderToolStripMenuItem.Size = new System.Drawing.Size(205, 22);
            this.productsReorderToolStripMenuItem.Text = "Products Reorder  Point";
            // 
            // purchaseOrderToolStripMenuItem
            // 
            this.purchaseOrderToolStripMenuItem.Name = "purchaseOrderToolStripMenuItem";
            this.purchaseOrderToolStripMenuItem.Size = new System.Drawing.Size(205, 22);
            this.purchaseOrderToolStripMenuItem.Text = "Purchase Order";
            // 
            // purchaseProductToolStripMenuItem
            // 
            this.purchaseProductToolStripMenuItem.Name = "purchaseProductToolStripMenuItem";
            this.purchaseProductToolStripMenuItem.Size = new System.Drawing.Size(205, 22);
            this.purchaseProductToolStripMenuItem.Text = "Purchase Reiceve";
            // 
            // stockBalancesToolStripMenuItem
            // 
            this.stockBalancesToolStripMenuItem.Name = "stockBalancesToolStripMenuItem";
            this.stockBalancesToolStripMenuItem.Size = new System.Drawing.Size(205, 22);
            this.stockBalancesToolStripMenuItem.Text = "Stock Balances";
            // 
            // pointOfPaymentToolStripMenuItem
            // 
            this.pointOfPaymentToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.salesCollectionReportToolStripMenuItem,
            this.salesCollectionReportVOIDToolStripMenuItem,
            this.collectionSummaryReportToolStripMenuItem,
            this.salesReceiptReportToolStripMenuItem,
            this.fastAndSlowMovingToolStripMenuItem});
            this.pointOfPaymentToolStripMenuItem.Name = "pointOfPaymentToolStripMenuItem";
            this.pointOfPaymentToolStripMenuItem.Size = new System.Drawing.Size(205, 22);
            this.pointOfPaymentToolStripMenuItem.Text = "Point Of Payment";
            // 
            // salesCollectionReportToolStripMenuItem
            // 
            this.salesCollectionReportToolStripMenuItem.Name = "salesCollectionReportToolStripMenuItem";
            this.salesCollectionReportToolStripMenuItem.Size = new System.Drawing.Size(249, 22);
            this.salesCollectionReportToolStripMenuItem.Text = "Sales Collection Report";
            // 
            // salesCollectionReportVOIDToolStripMenuItem
            // 
            this.salesCollectionReportVOIDToolStripMenuItem.Name = "salesCollectionReportVOIDToolStripMenuItem";
            this.salesCollectionReportVOIDToolStripMenuItem.Size = new System.Drawing.Size(249, 22);
            this.salesCollectionReportVOIDToolStripMenuItem.Text = "Sales Collection Report ( VOID )";
            // 
            // collectionSummaryReportToolStripMenuItem
            // 
            this.collectionSummaryReportToolStripMenuItem.Name = "collectionSummaryReportToolStripMenuItem";
            this.collectionSummaryReportToolStripMenuItem.Size = new System.Drawing.Size(249, 22);
            this.collectionSummaryReportToolStripMenuItem.Text = "Collection Summary Report";
            // 
            // salesReceiptReportToolStripMenuItem
            // 
            this.salesReceiptReportToolStripMenuItem.Name = "salesReceiptReportToolStripMenuItem";
            this.salesReceiptReportToolStripMenuItem.Size = new System.Drawing.Size(249, 22);
            this.salesReceiptReportToolStripMenuItem.Text = "Sales Receipt Report";
            // 
            // fastAndSlowMovingToolStripMenuItem
            // 
            this.fastAndSlowMovingToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fastMovingToolStripMenuItem,
            this.slowMovingToolStripMenuItem});
            this.fastAndSlowMovingToolStripMenuItem.Name = "fastAndSlowMovingToolStripMenuItem";
            this.fastAndSlowMovingToolStripMenuItem.Size = new System.Drawing.Size(249, 22);
            this.fastAndSlowMovingToolStripMenuItem.Text = "Fast and Slow Moving";
            // 
            // fastMovingToolStripMenuItem
            // 
            this.fastMovingToolStripMenuItem.Name = "fastMovingToolStripMenuItem";
            this.fastMovingToolStripMenuItem.Size = new System.Drawing.Size(142, 22);
            this.fastMovingToolStripMenuItem.Text = "Fast Moving";
            // 
            // slowMovingToolStripMenuItem
            // 
            this.slowMovingToolStripMenuItem.Name = "slowMovingToolStripMenuItem";
            this.slowMovingToolStripMenuItem.Size = new System.Drawing.Size(142, 22);
            this.slowMovingToolStripMenuItem.Text = "Slow Moving";
            // 
            // panel3
            // 
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel3.Controls.Add(this.dateLbl);
            this.panel3.Controls.Add(this.timeLbl);
            this.panel3.Controls.Add(this.lbltime);
            this.panel3.Controls.Add(this.BtnLogout);
            this.panel3.Controls.Add(this.lbltoday);
            this.panel3.Controls.Add(this.label2);
            this.panel3.Controls.Add(this.lblUser);
            this.panel3.Controls.Add(this.label1);
            this.panel3.Controls.Add(this.Label5);
            this.panel3.Controls.Add(this.userPic);
            this.panel3.Controls.Add(this.Label4);
            this.panel3.Controls.Add(this.Label3);
            this.panel3.Location = new System.Drawing.Point(4, 28);
            this.panel3.Margin = new System.Windows.Forms.Padding(4);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(241, 108);
            this.panel3.TabIndex = 12;
            // 
            // dateLbl
            // 
            this.dateLbl.AutoSize = true;
            this.dateLbl.Font = new System.Drawing.Font("Tahoma", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.dateLbl.Location = new System.Drawing.Point(49, 70);
            this.dateLbl.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.dateLbl.Name = "dateLbl";
            this.dateLbl.Size = new System.Drawing.Size(25, 12);
            this.dateLbl.TabIndex = 16;
            this.dateLbl.Text = "Date";
            // 
            // timeLbl
            // 
            this.timeLbl.AutoSize = true;
            this.timeLbl.Font = new System.Drawing.Font("Tahoma", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.timeLbl.Location = new System.Drawing.Point(35, 87);
            this.timeLbl.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.timeLbl.Name = "timeLbl";
            this.timeLbl.Size = new System.Drawing.Size(29, 12);
            this.timeLbl.TabIndex = 15;
            this.timeLbl.Text = " Time";
            // 
            // lbltime
            // 
            this.lbltime.AutoSize = true;
            this.lbltime.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lbltime.ForeColor = System.Drawing.Color.Red;
            this.lbltime.Location = new System.Drawing.Point(70, 86);
            this.lbltime.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbltime.Name = "lbltime";
            this.lbltime.Size = new System.Drawing.Size(0, 13);
            this.lbltime.TabIndex = 14;
            // 
            // BtnLogout
            // 
            this.BtnLogout.BackColor = System.Drawing.Color.White;
            this.BtnLogout.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.BtnLogout.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.BtnLogout.Image = ((System.Drawing.Image)(resources.GetObject("BtnLogout.Image")));
            this.BtnLogout.Location = new System.Drawing.Point(179, 58);
            this.BtnLogout.Margin = new System.Windows.Forms.Padding(4);
            this.BtnLogout.Name = "BtnLogout";
            this.BtnLogout.Size = new System.Drawing.Size(49, 46);
            this.BtnLogout.TabIndex = 3;
            this.BtnLogout.UseVisualStyleBackColor = false;
            // 
            // lbltoday
            // 
            this.lbltoday.AutoSize = true;
            this.lbltoday.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lbltoday.Location = new System.Drawing.Point(71, 70);
            this.lbltoday.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbltoday.Name = "lbltoday";
            this.lbltoday.Size = new System.Drawing.Size(0, 13);
            this.lbltoday.TabIndex = 13;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Tahoma", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label2.ForeColor = System.Drawing.SystemColors.Highlight;
            this.label2.Location = new System.Drawing.Point(65, 18);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(149, 17);
            this.label2.TabIndex = 2;
            this.label2.Text = "Point of Sale System";
            // 
            // lblUser
            // 
            this.lblUser.AutoSize = true;
            this.lblUser.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblUser.Location = new System.Drawing.Point(70, 53);
            this.lblUser.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblUser.Name = "lblUser";
            this.lblUser.Size = new System.Drawing.Size(0, 13);
            this.lblUser.TabIndex = 12;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Tahoma", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label1.ForeColor = System.Drawing.SystemColors.Highlight;
            this.label1.Location = new System.Drawing.Point(66, 2);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(139, 17);
            this.label1.TabIndex = 1;
            this.label1.Text = "Future Craft Digital";
            // 
            // Label5
            // 
            this.Label5.AutoSize = true;
            this.Label5.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Label5.Location = new System.Drawing.Point(1, 86);
            this.Label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Label5.Name = "Label5";
            this.Label5.Size = new System.Drawing.Size(36, 13);
            this.Label5.TabIndex = 11;
            this.Label5.Text = "Clock:";
            // 
            // userPic
            // 
            this.userPic.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("userPic.BackgroundImage")));
            this.userPic.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.userPic.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.userPic.Location = new System.Drawing.Point(-2, 0);
            this.userPic.Margin = new System.Windows.Forms.Padding(4);
            this.userPic.Name = "userPic";
            this.userPic.Size = new System.Drawing.Size(56, 49);
            this.userPic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.userPic.TabIndex = 0;
            this.userPic.TabStop = false;
            // 
            // Label4
            // 
            this.Label4.AutoSize = true;
            this.Label4.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Label4.Location = new System.Drawing.Point(-1, 69);
            this.Label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Label4.Name = "Label4";
            this.Label4.Size = new System.Drawing.Size(51, 13);
            this.Label4.TabIndex = 10;
            this.Label4.Text = "Today is:";
            // 
            // Label3
            // 
            this.Label3.AutoSize = true;
            this.Label3.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Label3.Location = new System.Drawing.Point(0, 53);
            this.Label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Label3.Name = "Label3";
            this.Label3.Size = new System.Drawing.Size(54, 13);
            this.Label3.TabIndex = 9;
            this.Label3.Text = "Welcome:";
            // 
            // contentPanel
            // 
            this.contentPanel.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.contentPanel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.contentPanel.Controls.Add(this.HomePageLogo);
            this.contentPanel.Location = new System.Drawing.Point(250, 92);
            this.contentPanel.Margin = new System.Windows.Forms.Padding(4);
            this.contentPanel.Name = "contentPanel";
            this.contentPanel.Size = new System.Drawing.Size(815, 658);
            this.contentPanel.TabIndex = 39;
            // 
            // HomePageLogo
            // 
            this.HomePageLogo.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.HomePageLogo.Image = ((System.Drawing.Image)(resources.GetObject("HomePageLogo.Image")));
            this.HomePageLogo.Location = new System.Drawing.Point(40, 184);
            this.HomePageLogo.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.HomePageLogo.Name = "HomePageLogo";
            this.HomePageLogo.Size = new System.Drawing.Size(736, 295);
            this.HomePageLogo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.HomePageLogo.TabIndex = 6;
            this.HomePageLogo.TabStop = false;
            // 
            // Home
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1199, 562);
            this.Controls.Add(this.contentPanel);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.flowLayoutPanel1);
            this.Controls.Add(this.panel7);
            this.Controls.Add(this.PanelShortCut);
            this.Controls.Add(this.panel2);
            this.IsMdiContainer = true;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Home";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Future Craft Digital POS";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.PanelShortCut.ResumeLayout(false);
            this.PanelShortCut.PerformLayout();
            this.panel7.ResumeLayout(false);
            this.PanelAdvisory.ResumeLayout(false);
            this.panel8.ResumeLayout(false);
            this.Panel9.ResumeLayout(false);
            this.Panel9.PerformLayout();
            this.Panel10.ResumeLayout(false);
            this.pnAdvisory_Cashier.ResumeLayout(false);
            this.pnAdvisory_Cashier.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox11)).EndInit();
            this.pnadvisory_Admin.ResumeLayout(false);
            this.pnadvisory_Admin.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox3)).EndInit();
            this.pnAdvisory_SalesAgent.ResumeLayout(false);
            this.pnAdvisory_SalesAgent.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox12)).EndInit();
            this.pnAdvisory_Stock.ResumeLayout(false);
            this.pnAdvisory_Stock.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox7)).EndInit();
            this.flowLayoutPanel1.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.userPic)).EndInit();
            this.contentPanel.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.HomePageLogo)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private Panel panel2;
        internal Button BtnPrint;
        internal Button BtnSearch;
        internal Button BtnRefresh;
        internal Button BtnDelete;
        internal Button BtnEdit;
        internal Button BtnNew;
        internal Panel PanelShortCut;
        internal LinkLabel openShortCutsLink;
        internal ListView shortcutList;
        internal ColumnHeader columIcons;
        internal ColumnHeader ColumnHeader1;
        private Panel panel7;
        internal Panel PanelAdvisory;
        internal Panel panel8;
        internal Panel Panel9;
        internal TextBox txttabstop;
        internal Panel Panel10;
        internal Panel pnAdvisory_Cashier;
        internal Label Label8;
        internal PictureBox PictureBox11;
        internal Panel pnadvisory_Admin;
        internal PictureBox PictureBox6;
        internal PictureBox PictureBox5;
        internal PictureBox PictureBox4;
        internal PictureBox PictureBox3;
        internal Label lblpurchasemonth;
        internal Label lblPurchaseYr;
        internal Label lblreorder;
        internal Label lblremainorder;
        internal Label lblinventory;
        internal Label lbltotalprod;
        internal Label lblmonthsales;
        internal Label lblyrsales;
        internal Panel pnAdvisory_SalesAgent;
        internal PictureBox PictureBox14;
        internal Label Label9;
        internal Label lblsalesagent_Criticalproduct;
        internal Label lblsalesagent_purchaseyear;
        internal Label lblsalesagent_purchaseMonth;
        internal PictureBox PictureBox13;
        internal Label lblsalesagent_totalInventory;
        internal Label lblsalesagent_totalorder;
        internal PictureBox PictureBox12;
        internal Panel pnAdvisory_Stock;
        internal Label lblstock_Undeliver;
        internal Label Label7;
        internal Label lblstock_critical;
        internal PictureBox PictureBox8;
        internal Label lblstock_received_year;
        internal Label lblstock_received_month;
        internal Label lblstock_tot_product;
        internal PictureBox PictureBox7;
        private FlowLayoutPanel flowLayoutPanel1;
        internal Button BtnExit;
        private Panel panel1;
        private Panel panel3;
        internal Label lbltime;
        private Button BtnLogout;
        internal Label lbltoday;
        private Label label2;
        internal Label lblUser;
        private Label label1;
        internal Label Label5;
        private PictureBox userPic;
        internal Label Label4;
        internal Label Label3;
        private Panel panel4;
        private Button BtnBusinessInfo;
        private Button BtnUserLog;
        private Button BtnUserRecords;
        private Button BtnManageSuppliers;
        private Button BtnProductListing;
        private LinkLabel linkLabel1;
        private Panel panel5;
        private Button BtnDefectiveStocks;
        private Button BtnCriticalProducts;
        private Button BtnPhysicalCount;
        private Button BtnStockMonitor;
        private Button BtnOrderAndReceive;
        private LinkLabel linkLabel2;
        private Panel panel6;
        private Button BtnSalesReceipt;
        private Button BtnCashiering;
        private Button BtnOrderingKiosk;
        private LinkLabel SalesAndOrderLinkLabel;
        private Label advisoryLabel;
        private MenuStrip menuStrip1;
        public ToolStripMenuItem systemFileToolStripMenuItem;
        private ToolStripMenuItem inventoryFileToolStripMenuItem;
        private ToolStripMenuItem categoryListToolStripMenuItem;
        private ToolStripMenuItem categoryItemListToolStripMenuItem;
        private ToolStripSeparator toolStripSeparator1;
        private ToolStripMenuItem manageSuppliesToolStripMenuItem;
        private ToolStripMenuItem suppliersProductToolStripMenuItem;
        private ToolStripSeparator toolStripSeparator2;
        private ToolStripMenuItem pointToolStripMenuItem;
        private ToolStripMenuItem cashieringToolStripMenuItem;
        private ToolStripMenuItem salesReceiptToolStripMenuItem;
        private ToolStripMenuItem manageUsersToolStripMenuItem;
        private ToolStripMenuItem usersLogToolStripMenuItem;
        private ToolStripMenuItem aboutToolStripMenuItem;
        private ToolStripMenuItem exitToolStripMenuItem;
        private ToolStripMenuItem reportsToolStripMenuItem;
        private ToolStripMenuItem supplierProfileToolStripMenuItem;
        private ToolStripMenuItem supplierProductsToolStripMenuItem;
        private ToolStripMenuItem productsReorderToolStripMenuItem;
        private ToolStripMenuItem purchaseOrderToolStripMenuItem;
        private ToolStripMenuItem purchaseProductToolStripMenuItem;
        private ToolStripMenuItem stockBalancesToolStripMenuItem;
        private ToolStripMenuItem pointOfPaymentToolStripMenuItem;
        private ToolStripMenuItem salesCollectionReportToolStripMenuItem;
        private ToolStripMenuItem salesCollectionReportVOIDToolStripMenuItem;
        private ToolStripMenuItem collectionSummaryReportToolStripMenuItem;
        private ToolStripMenuItem salesReceiptReportToolStripMenuItem;
        private ToolStripMenuItem fastAndSlowMovingToolStripMenuItem;
        private ToolStripMenuItem fastMovingToolStripMenuItem;
        private ToolStripMenuItem slowMovingToolStripMenuItem;
        private Panel contentPanel;
        private PictureBox HomePageLogo;
        internal Label timeLbl;
        internal Label dateLbl;
        internal Button BtnHome;
    }
}

