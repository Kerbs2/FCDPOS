﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Future_Craft_Digital.Sales_and_Order
{
    public partial class Ordering_Kiosk : Form
    {
        public Ordering_Kiosk()
        {
            InitializeComponent();
        }

        private void Ordering_Kiosk_Load(object sender, EventArgs e)
        {

        }
    }
}
