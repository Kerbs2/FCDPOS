﻿namespace Future_Craft_Digital
{
    partial class Cashiering
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Cashiering));
            pictureBox1 = new PictureBox();
            label2 = new Label();
            label1 = new Label();
            vatTextBox = new TextBox();
            totalSaleTextBox = new TextBox();
            quantityTextBox = new TextBox();
            vatableTextBox = new TextBox();
            vatExempTextBox = new TextBox();
            itemNameTextBox = new TextBox();
            orderNoTextBox = new TextBox();
            label10 = new Label();
            typeTextBox = new ComboBox();
            label9 = new Label();
            label6 = new Label();
            label8 = new Label();
            label5 = new Label();
            label7 = new Label();
            label4 = new Label();
            label3 = new Label();
            BtnAccept = new Button();
            panel1 = new Panel();
            listViewCashiering = new ListView();
            id = new ColumnHeader();
            itemName = new ColumnHeader();
            description = new ColumnHeader();
            price = new ColumnHeader();
            quantity = new ColumnHeader();
            groupBox1 = new GroupBox();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            panel1.SuspendLayout();
            groupBox1.SuspendLayout();
            SuspendLayout();
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(16, 16);
            pictureBox1.Margin = new Padding(3, 4, 3, 4);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(69, 60);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 4;
            pictureBox1.TabStop = false;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Tahoma", 9F, FontStyle.Regular, GraphicsUnit.Point);
            label2.ForeColor = Color.Black;
            label2.Location = new Point(91, 59);
            label2.Name = "label2";
            label2.RightToLeft = RightToLeft.No;
            label2.Size = new Size(195, 18);
            label2.TabIndex = 2;
            label2.Text = "Product(s) Sales Transaction";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Tahoma", 15.75F, FontStyle.Bold, GraphicsUnit.Point);
            label1.ForeColor = SystemColors.MenuHighlight;
            label1.Location = new Point(91, 28);
            label1.Name = "label1";
            label1.RightToLeft = RightToLeft.No;
            label1.Size = new Size(237, 33);
            label1.TabIndex = 3;
            label1.Text = "Sales Cashiering";
            // 
            // vatTextBox
            // 
            vatTextBox.BackColor = SystemColors.Info;
            vatTextBox.Enabled = false;
            vatTextBox.Location = new Point(611, 121);
            vatTextBox.Margin = new Padding(3, 4, 3, 4);
            vatTextBox.Name = "vatTextBox";
            vatTextBox.Size = new Size(199, 27);
            vatTextBox.TabIndex = 8;
            // 
            // totalSaleTextBox
            // 
            totalSaleTextBox.BackColor = Color.White;
            totalSaleTextBox.Enabled = false;
            totalSaleTextBox.Location = new Point(611, 87);
            totalSaleTextBox.Margin = new Padding(3, 4, 3, 4);
            totalSaleTextBox.Name = "totalSaleTextBox";
            totalSaleTextBox.Size = new Size(199, 27);
            totalSaleTextBox.TabIndex = 8;
            // 
            // quantityTextBox
            // 
            quantityTextBox.BackColor = Color.White;
            quantityTextBox.Enabled = false;
            quantityTextBox.Location = new Point(118, 121);
            quantityTextBox.Margin = new Padding(3, 4, 3, 4);
            quantityTextBox.Name = "quantityTextBox";
            quantityTextBox.Size = new Size(199, 27);
            quantityTextBox.TabIndex = 8;
            // 
            // vatableTextBox
            // 
            vatableTextBox.BackColor = Color.White;
            vatableTextBox.Enabled = false;
            vatableTextBox.Location = new Point(611, 17);
            vatableTextBox.Margin = new Padding(3, 4, 3, 4);
            vatableTextBox.Name = "vatableTextBox";
            vatableTextBox.Size = new Size(199, 27);
            vatableTextBox.TabIndex = 8;
            // 
            // vatExempTextBox
            // 
            vatExempTextBox.BackColor = Color.White;
            vatExempTextBox.Enabled = false;
            vatExempTextBox.Location = new Point(611, 52);
            vatExempTextBox.Margin = new Padding(3, 4, 3, 4);
            vatExempTextBox.Name = "vatExempTextBox";
            vatExempTextBox.Size = new Size(199, 27);
            vatExempTextBox.TabIndex = 8;
            // 
            // itemNameTextBox
            // 
            itemNameTextBox.BackColor = Color.White;
            itemNameTextBox.Enabled = false;
            itemNameTextBox.Location = new Point(118, 87);
            itemNameTextBox.Margin = new Padding(3, 4, 3, 4);
            itemNameTextBox.Name = "itemNameTextBox";
            itemNameTextBox.Size = new Size(199, 27);
            itemNameTextBox.TabIndex = 8;
            // 
            // orderNoTextBox
            // 
            orderNoTextBox.Location = new Point(118, 52);
            orderNoTextBox.Margin = new Padding(3, 4, 3, 4);
            orderNoTextBox.Name = "orderNoTextBox";
            orderNoTextBox.Size = new Size(199, 27);
            orderNoTextBox.TabIndex = 2;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Font = new Font("Tahoma", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            label10.ForeColor = Color.Black;
            label10.Location = new Point(496, 117);
            label10.Name = "label10";
            label10.Padding = new Padding(0, 7, 0, 7);
            label10.RightToLeft = RightToLeft.No;
            label10.Size = new Size(113, 35);
            label10.TabIndex = 6;
            label10.Text = "VAT - 12% :";
            // 
            // typeTextBox
            // 
            typeTextBox.DropDownStyle = ComboBoxStyle.DropDownList;
            typeTextBox.FormattingEnabled = true;
            typeTextBox.Location = new Point(118, 17);
            typeTextBox.Margin = new Padding(3, 4, 3, 4);
            typeTextBox.Name = "typeTextBox";
            typeTextBox.Size = new Size(199, 28);
            typeTextBox.TabIndex = 1;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Tahoma", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            label9.ForeColor = Color.Black;
            label9.Location = new Point(506, 83);
            label9.Name = "label9";
            label9.Padding = new Padding(0, 7, 0, 7);
            label9.RightToLeft = RightToLeft.No;
            label9.Size = new Size(103, 35);
            label9.TabIndex = 6;
            label9.Text = "Total sale :";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Tahoma", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            label6.ForeColor = Color.Black;
            label6.Location = new Point(24, 117);
            label6.Name = "label6";
            label6.Padding = new Padding(0, 7, 0, 7);
            label6.RightToLeft = RightToLeft.No;
            label6.Size = new Size(95, 35);
            label6.TabIndex = 6;
            label6.Text = "Quantity :";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Tahoma", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            label8.ForeColor = Color.Black;
            label8.Location = new Point(458, 48);
            label8.Name = "label8";
            label8.Padding = new Padding(0, 7, 0, 7);
            label8.RightToLeft = RightToLeft.No;
            label8.Size = new Size(157, 35);
            label8.TabIndex = 6;
            label8.Text = "VAT-Exemp sale :";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Tahoma", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            label5.ForeColor = Color.Black;
            label5.Location = new Point(9, 83);
            label5.Name = "label5";
            label5.Padding = new Padding(0, 7, 0, 7);
            label5.RightToLeft = RightToLeft.No;
            label5.Size = new Size(114, 35);
            label5.TabIndex = 6;
            label5.Text = "Item name :";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Tahoma", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            label7.ForeColor = Color.Black;
            label7.Location = new Point(515, 13);
            label7.Name = "label7";
            label7.Padding = new Padding(0, 7, 0, 7);
            label7.RightToLeft = RightToLeft.No;
            label7.Size = new Size(90, 35);
            label7.TabIndex = 6;
            label7.Text = "VATable :";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Tahoma", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            label4.ForeColor = Color.Black;
            label4.Location = new Point(18, 48);
            label4.Name = "label4";
            label4.Padding = new Padding(0, 7, 0, 7);
            label4.RightToLeft = RightToLeft.No;
            label4.Size = new Size(103, 35);
            label4.TabIndex = 6;
            label4.Text = "Order No. :";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Tahoma", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            label3.ForeColor = Color.Black;
            label3.Location = new Point(3, 13);
            label3.Name = "label3";
            label3.Padding = new Padding(0, 7, 0, 7);
            label3.RightToLeft = RightToLeft.No;
            label3.Size = new Size(116, 35);
            label3.TabIndex = 6;
            label3.Text = "Select type :";
            // 
            // BtnAccept
            // 
            BtnAccept.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
            BtnAccept.Font = new Font("Tahoma", 12F, FontStyle.Bold, GraphicsUnit.Point);
            BtnAccept.Location = new Point(11, 820);
            BtnAccept.Margin = new Padding(3, 4, 3, 4);
            BtnAccept.Name = "BtnAccept";
            BtnAccept.Size = new Size(164, 45);
            BtnAccept.TabIndex = 3;
            BtnAccept.Text = "Accept";
            BtnAccept.UseVisualStyleBackColor = true;
            // 
            // panel1
            // 
            panel1.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            panel1.Controls.Add(vatTextBox);
            panel1.Controls.Add(vatableTextBox);
            panel1.Controls.Add(totalSaleTextBox);
            panel1.Controls.Add(label3);
            panel1.Controls.Add(quantityTextBox);
            panel1.Controls.Add(label4);
            panel1.Controls.Add(label7);
            panel1.Controls.Add(vatExempTextBox);
            panel1.Controls.Add(label5);
            panel1.Controls.Add(itemNameTextBox);
            panel1.Controls.Add(label8);
            panel1.Controls.Add(orderNoTextBox);
            panel1.Controls.Add(label6);
            panel1.Controls.Add(label10);
            panel1.Controls.Add(label9);
            panel1.Controls.Add(typeTextBox);
            panel1.Location = new Point(16, 95);
            panel1.Margin = new Padding(3, 4, 3, 4);
            panel1.Name = "panel1";
            panel1.Size = new Size(1153, 165);
            panel1.TabIndex = 6;
            // 
            // listViewCashiering
            // 
            listViewCashiering.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            listViewCashiering.Columns.AddRange(new ColumnHeader[] { id, itemName, description, price, quantity });
            listViewCashiering.FullRowSelect = true;
            listViewCashiering.GridLines = true;
            listViewCashiering.Location = new Point(3, 24);
            listViewCashiering.Margin = new Padding(3, 4, 3, 4);
            listViewCashiering.Name = "listViewCashiering";
            listViewCashiering.Size = new Size(1136, 507);
            listViewCashiering.TabIndex = 1;
            listViewCashiering.UseCompatibleStateImageBehavior = false;
            listViewCashiering.View = View.Details;
            // 
            // id
            // 
            id.Text = "ID";
            // 
            // itemName
            // 
            itemName.Text = "Item name";
            itemName.Width = 200;
            // 
            // description
            // 
            description.Text = "Description";
            description.Width = 350;
            // 
            // price
            // 
            price.Text = "Price";
            price.Width = 100;
            // 
            // quantity
            // 
            quantity.Text = "Quantity";
            quantity.Width = 100;
            // 
            // groupBox1
            // 
            groupBox1.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            groupBox1.Controls.Add(listViewCashiering);
            groupBox1.Location = new Point(11, 268);
            groupBox1.Margin = new Padding(3, 4, 3, 4);
            groupBox1.Name = "groupBox1";
            groupBox1.Padding = new Padding(3, 4, 3, 4);
            groupBox1.Size = new Size(1158, 539);
            groupBox1.TabIndex = 5;
            groupBox1.TabStop = false;
            // 
            // Cashiering
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1183, 907);
            ControlBox = false;
            Controls.Add(panel1);
            Controls.Add(BtnAccept);
            Controls.Add(groupBox1);
            Controls.Add(pictureBox1);
            Controls.Add(label2);
            Controls.Add(label1);
            FormBorderStyle = FormBorderStyle.None;
            Margin = new Padding(3, 4, 3, 4);
            MinimumSize = new Size(1183, 907);
            Name = "Cashiering";
            Text = "Cashiering";
            WindowState = FormWindowState.Maximized;
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            groupBox1.ResumeLayout(false);
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private PictureBox pictureBox1;
        private Label label2;
        private Label label1;
        private TextBox quantityTextBox;
        private TextBox itemNameTextBox;
        private TextBox orderNoTextBox;
        private ComboBox typeTextBox;
        private Label label6;
        private Label label5;
        private Label label4;
        private Label label3;
        private TextBox vatTextBox;
        private TextBox totalSaleTextBox;
        private TextBox vatableTextBox;
        private TextBox vatExempTextBox;
        private Label label10;
        private Label label9;
        private Label label8;
        private Label label7;
        private Button BtnAccept;
        private Panel panel1;
        private ListView listViewCashiering;
        private ColumnHeader id;
        private ColumnHeader itemName;
        private ColumnHeader description;
        private ColumnHeader price;
        private ColumnHeader quantity;
        private GroupBox groupBox1;
    }
}