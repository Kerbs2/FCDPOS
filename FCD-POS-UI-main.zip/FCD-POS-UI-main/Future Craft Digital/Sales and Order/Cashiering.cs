namespace Future_Craft_Digital
{
    public partial class Cashiering : Form
    {
        public Cashiering()
        {
            InitializeComponent();
        }
    }
}