﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Future_Craft_Digital.Maintenance
{
    public partial class ProductListingForm : Form
    {
        public ProductListingForm()
        {
            InitializeComponent();
        }

        private void itemByCategoryBtn_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void categoryBtn_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void listItemFileProdBtn_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void brandBtn_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void prodListingDesc_Click(object sender, EventArgs e)
        {

        }
    }
}
