﻿using System.Windows.Forms;

namespace Future_Craft_Digital.Maintenance
{
    public partial class ManageSupplierForm : Form
    {
        public ManageSupplierForm()
        {
            InitializeComponent();
        }
    }
}
